import cv2

url = "http://192.168.4.1:81/stream"
#url = "http://192.168.11.27:81/stream"

cap = cv2.VideoCapture(url)

while True:
    ret, frame = cap.read()
    if not ret:
        break
    flipped_frame = cv2.flip(frame, 1)    
    cv2.imshow('ESP32-CAM', flipped_frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
